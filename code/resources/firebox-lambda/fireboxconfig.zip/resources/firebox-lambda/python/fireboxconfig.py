from __future__ import print_function

def configure_firebox(event, context):
    print 'Hello World!'  
    return 'Hello World'